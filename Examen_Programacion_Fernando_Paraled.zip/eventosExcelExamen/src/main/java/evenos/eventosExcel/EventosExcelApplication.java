package evenos.eventosExcel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventosExcelApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventosExcelApplication.class, args);
	}

}
