package eventos.pdfEventos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfEventosApplicationTests {

	@Test
	void contextLoads() {
	}

}
